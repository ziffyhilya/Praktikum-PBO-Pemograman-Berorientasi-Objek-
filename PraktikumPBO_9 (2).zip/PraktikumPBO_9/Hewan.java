/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_Modul9;

/**
 *
 * @author Pongo
 */
abstract class Hewan {
    // Metode abstrak
    abstract void Suara();
   // Metode dengan implementasi
    void info() {
        System.out.println("Ini adalah suara hewan lucu.");
    }
}
