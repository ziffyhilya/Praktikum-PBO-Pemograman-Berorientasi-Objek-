/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_Modul9;

/**
 *
 * @author Pongo
 */
public class Main {
    public static void main(String[] args) {
    Hewan Kucing = new Kucing();
    Hewan Anjing = new Anjing();
    
    Kucing.Suara();
    Kucing.info();
    
    Anjing.Suara();
    Anjing.info();
    }   
}
