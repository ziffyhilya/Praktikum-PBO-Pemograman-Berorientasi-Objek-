/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_Modul9;

/**
 *
 * @author Pongo
 */
class Anjing extends Hewan{
    @Override
    void Suara() {
        System.out.println("Anjing mengeluarkan suara: Guk Guk");
    } 
}
