/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author Pongo
 */
public class Kendaraan {
    String nama;
    int kecepatan;
    
    public void tampilkaninfo(){
        System.out.println("Nama Kendaraan:" + nama);
        System.out.println("Kecepatan:" + kecepatan);
    }
} 

