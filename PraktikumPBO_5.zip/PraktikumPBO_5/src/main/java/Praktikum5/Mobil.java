/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author Pongo
 */
public class Mobil extends Kendaraan{
    int jumlahPintu;
    
    @Override
    public void tampilkaninfo(){
        super.tampilkaninfo(); 
        System.out.println("jumlah Pintu:" + jumlahPintu);
    }
}
    
