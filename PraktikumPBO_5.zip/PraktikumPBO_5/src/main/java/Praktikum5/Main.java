/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author Pongo
 */
public class Main {
    public static void main(String[] args){
        //Mobil
        Mobil mobil = new Mobil();
        mobil.nama = "Mcleren";
        mobil.kecepatan = 320;
        mobil.jumlahPintu = 2;
        System.out.println("---Informasi Mobil---");
        mobil.tampilkaninfo();
        
        //SepedaMotor
        
        SepedaMotor motor = new SepedaMotor();
        motor.nama = "bebek";
        motor.kecepatan = 280;
        motor.jenisMesin = "Ducati";
        System.out.println("---Informasi Sepeda Motor---");
        motor.tampilkaninfo();
    }
   
}
