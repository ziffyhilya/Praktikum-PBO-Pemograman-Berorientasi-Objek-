/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_praktikum5;

/**
 *
 * @author Pongo
 */
public class Kucing extends Hewan {
    String warnaBulu;
    
    //Overring metode suara
    @Override
    public void suara(){
        System.out.println("Suara : Miaw miaww!!");
    }
    
    //Overring metode infoHewan
    @Override
    public void infoHewan(){
        super.infoHewan();
        System.out.println("Warna Bulu" + warnaBulu );
        suara();// Memanggil suara  kucing
    } 
}
