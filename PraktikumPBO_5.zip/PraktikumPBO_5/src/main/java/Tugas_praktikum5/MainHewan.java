/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_praktikum5;

/**
 *
 * @author Pongo
 */
public class MainHewan {
    public static void main(String[] args){
        Kucing kucing = new Kucing();
        kucing.nama = "mamad";
        kucing.jenis = "galak tapi berhati hellokitty";
        kucing.warnaBulu = "Coklat";
        
        System.out.println("===Data Kucing===");       
        kucing.infoHewan();
        
        System.out.println();
        
        Anjing anjing = new Anjing();
        anjing.nama = "anjayy";
        anjing.jenis = "galak tapi imud";
        anjing.ras = "Pomeranian";
        
        System.out.println("===Data Anjing===");
        anjing.infoHewan();
              
    }
    
}
