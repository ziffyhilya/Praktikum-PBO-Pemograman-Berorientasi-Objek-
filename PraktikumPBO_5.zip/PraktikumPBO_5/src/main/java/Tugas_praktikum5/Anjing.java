/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_praktikum5;

/**
 *
 * @author Pongo
 */
public class Anjing extends Hewan {
    String ras;
    
    //Overriding metode suara
    @Override
    public void suara() {
        System.out.println("Suara : gukk gukk!!");
    }
    
    //Overriding metode infoHewan
    @Override
    public void infoHewan(){
        super.infoHewan();
        System.out.println("Ras : "+ras);
        suara(); // Memanggil suara anjing
    } 
    
}
