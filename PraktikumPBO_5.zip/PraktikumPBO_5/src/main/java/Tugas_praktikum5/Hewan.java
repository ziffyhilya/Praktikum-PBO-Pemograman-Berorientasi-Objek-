/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_praktikum5;

/**
 *
 * @author Pongo
 */
public class Hewan {
    String nama;
    String jenis;
    
    public void suara(){
        System.out.println("Hewan membuat suara.");
    }
    
    public void infoHewan(){
        System.out.println("nama:"+ nama);
        System.out.println("jenis:"+ jenis);
    }
}
