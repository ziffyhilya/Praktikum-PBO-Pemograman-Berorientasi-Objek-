/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ResponsiPBO;

/**
 *
 * @author Pongo
 */
public class Main {
    public static void main(String[] args) {
        // Output Produk
        Produk p1 = new Elektronik("Laptop", 1500000, 2);
        p1.tampilkanInfo();

        System.out.println();

        // Output Pegawai
        Pegawai pg1 = new PegawaiTetap("Ziffy", 500000, 1000000);
        pg1.tampilkanInfo();

        System.out.println();

        // Output Polimorfisme
        Produk p2 = new Makanan("Snack", 15000, "2023-12-30");
        Pegawai pg2 = new PegawaiKontrak("Hilya", 300000, 12);

        p2.tampilkanInfo();

        System.out.println();

        pg2.tampilkanInfo();
   
    }
}
