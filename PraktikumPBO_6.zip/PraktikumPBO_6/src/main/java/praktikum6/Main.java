/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum6;

/**
 *
 * @author Pongo
 */
public class Main {
    public static void main(String[] args){
        Hewan hewan = new Kucing();
        hewan.bersuara(); // output: Meow
        
        Kucing kucing = new Kucing();
        kucing.makan("ikan");// Memanggil metode makan() dari kelas hewan
        kucing.makan("ikan", 2);// Memanggil metode makan() yang overload
        
        Anjing anjing = new Anjing();
        anjing.bersuara();//Output: woof
        anjing.makan("daging",3);// Memanggil metode makan() yang overload pada kelas hewan;
    }
} 