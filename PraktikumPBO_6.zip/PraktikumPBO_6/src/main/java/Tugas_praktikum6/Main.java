/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas_praktikum6;

/**
 *
 * @author Pongo
 */
public class Main {
     public static void main(String[] args) {

        KeranjangBelanja keranjang = new KeranjangBelanja();

        keranjang.tambahProduk(new Buku("Pemrograman Java", 100000));
        keranjang.tambahProduk(new Elektronik("Mouse Wireless", 200000));
        keranjang.tambahProduk(new Pakaian("Kaos Polos", 150000));

        keranjang.tampilkanDetail();

        System.out.println("\nTotal Harga Setelah Diskon: " + keranjang.hitungTotalHarga());
    }
}
